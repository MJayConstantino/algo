from line_segment import LineSegment
from point import Point


class BruteCollinearPoints:
    def __init__(self, points: list[Point]):
        # YOUR CODE HERE
        pass

    def number_of_segments(self) -> int:
        # YOUR CODE HERE
        pass

    def segments(self) -> list[LineSegment]:
        # YOUR CODE HERE
        pass