from lib.weighted_quick_union_uf import WeightedQuickUnionUF


class Percolation:
    # creates n-by-n grid, with all sites initially blocked
    def __init__(self, n: int):
        pass

    # opens the site (row, col) if it is not open already
    def open(self, row: int, col: int) -> None:
        pass

    # is the site (row, col) open?
    def is_open(self, row: int, col: int) -> bool:
        pass

    # is the site (row, col) full?
    def is_full(self, row: int, col: int) -> bool:
        pass

    # returns the number of open sites
    def number_of_open_sites(self) -> int:
        pass

    # does the system percolate?
    def percolates(self) -> bool:
        pass

    # test client (optional)
    @staticmethod
    def main():
        pass


if __name__ == "__main__":
    Percolation.main()
